var i =  Math.floor((Math.random() * 10) + 1); 
var i1 =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);
var h1 = lbl(i1);
var l1 = 5;
var l2 = 7;

url = urll("www.attacker.com");
sink('Sink', '', url);


if (h > 5) {h1 = l1;}
else {h1 = l2;} 
var l3 = l1;
url1 = urll("www.attacker.com");
sink('Sink', '', url1);
