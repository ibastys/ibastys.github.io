var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);

if (h > 5) { var x = Date.now();}

url1 = urll("www.attacker.com" + 1);
sink('Sink', '', url1);

