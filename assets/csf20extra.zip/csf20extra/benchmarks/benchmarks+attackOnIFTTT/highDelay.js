var i =  Math.floor((Math.random() * 10) + 1); 


var h = lbl(i);

var t =  Date.now();

if (h%2 == t%2) {h = h;}
else {h = h;h = h;h = h;h = h;h = h;h = h;h = h;}


url = urll("www.attacker.com" + 1);
sink('Sink', '', url);