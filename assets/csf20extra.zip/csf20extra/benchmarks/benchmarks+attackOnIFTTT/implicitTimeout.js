var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);

url1 = urll("www.attacker.com" + 1);
url2 = urll("www.attacker.com" + 2);


if (h > 5) {sink('Sink', '', url1); sink('timeoutL'); }
else {sink('Sink', '', url1);sink('Sink', '', url2);}


// Note that timout is modelled as sink('timeoutL')
