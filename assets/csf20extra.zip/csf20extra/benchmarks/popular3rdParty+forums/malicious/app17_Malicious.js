// https://www.reddit.com/r/ifttt/comments/79jzqg/filter_code_trello_and_outlook/

// Applet that sends a Slack notification and an Email if a Trello card is added to a specific list and it works perfectly.
// The card contains the "US" string in its code.

// Trigger: Trello.cardAddedToList
// Action: Slack.postToChannel
// Action: Email.sendMeEmail

trigger_title = 'Trello.cardAddedToList.Title';
trigger_creatorName = lbl('Trello.cardAddedToList.CreatorFullName');
trigger_cardURL = lbl('Trello.cardAddedToList.cardURL');
allin = trigger_title + trigger_creatorName + trigger_cardURL;

cardTitle = trigger_title;
matchingCard = cardTitle.search("US");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (trigger_cardURL.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

if (!(matchingCard == -1)) {
	// Slack.postToChannel.skip();
  skip('Slack.postToChannel');
	}
else {
	// Email.sendMeEmail.setBody("An US card has been added to the list." + imgl(...));
	sink('Email.sendMeEmail', 'setBody', "An US card has been added to the list." +	res);
	}
