## NOTE: 

This document highlights the files in JSFlow that have been edited and describes the changes.
Edits prepended by `-` are FlowIT-specific, while edits prepended by `+` are Clockwork-specific. 


# context.js
- extend the Context `constructor` with `actionSet` and `blackValues`
`blackValues` = list of blacklisted values, i.e. array of Strings
`actionSet`   = list of actions, contains objects with 3 attributes:
  - `action` : String is the name of the action
  - `skip`   : Bool   is a boolean specifying whether the action has been skipped or not
  - `sink`   : Value  is a labeled value specifying the current value on the sink 
- initially, all skips are false and values on sink are null

+ extends the Context `constructor` with `highestPC`, `lowOutputs`, and `theta`


# jsflow.js
- extended with variables `sensitive` and `available`
- when executing ./jsflow with the flag `sensitive`, no blacklisted values are allowed on the sink; all variables should be low, since we do not want to enforce IFC in this case
- when executing ./jsflow with the flag `available`, skip statements will be ignored


# monitor.js
- extended the initialization function MonitorBase.prototype.initialize with instantiations of `actionSet`, `blackValues`, and `availabilitySet`

+ extended the initialization function MonitorBase.prototype.initialize with instantiations of `highestPC`, `lowOutputs`, and `theta`, i.e. `highestPC = new imports.label.Label()`, `lowOutputs = false`, `theta = false`



# constants.js
- extended `strings` with keywords `sink` and `skip`


# global.js
- extended ecma with several functions: `sink` and `skip`, `imgl`, `imgh`, `urll`, `urlh`
- `skip` takes as argument a String `s`; if `s` corresponds to one of the actions in `actionSet`, then the skip value corresponding to it will be set to true
- `sink` takes as arguments two String values `s1` and `s2` and a labeled value `v`; 
  - `s1` corresponds to the action, `s2` to the action's ingredient
  - if the skip corresponding to action `s1` in the actionSet is `true`, then nothing to do
  - else we update the value on the sink if 
      (1) pc <= label(`v`) and if 
      (2) if pc = H there no blacklisted values currently on the sink

  + if the value output has label L, then `lowOutputs` becomes `true`

- `imgl` and `imgh` are constructs for creating an image constructor; they take as argument a String `s` denoting the URL of the image. `imgl(s)` is assumed to create an image of size 0x0; `imgl` cannot take as argument a string containing a high labeled value, while `imgh` cannot take as argument a string containing a blacklisted value.
- `urll` and `urlh` are constructs for creating URLs. `urll` is used for creating privately and publicly visible links. `urll` cannot take as argument a string containing a high labeled value, while `urlh` cannot take as argument a string containing a blacklisted value.


# date.js
+ updated function `now` (lines 157-163) to return the PC as label (`monitor.context.effectivePC`)
+ updated Date constructor (lines 88) to return the PC as label (`monitor.context.effectivePC`)

+ if a `Date` constructor is invoked, then `theta` becomes `true` (line 89)
+ a `DateConstructor` has the label of the current PC (`monitor.context.effectivePC`) (line 88)
+ changed function `now` to return label `monitor.context.effectivePC` (lines 161) and to set `theta` to `true` (line 159)
+ changed function `mkGenericGet` to return label `monitor.context.effectivePC` (line 253)


# exec.js
- we treat `imgH` and `imgL` as special variables 
- we extend the function 'assignmentOps' with the following checks:
    - an assignment made to `imgH` is allowed only if the value assigned does not contain     
      blacklisted strings
    - an assignment made to `imgL` is allowed if it is made in a low context and the label of the 
      value assigned is low
- this works only for statements as 'img* = ...', not for 'var img* = ...'

+ extended functions `ifStatementChoose` (lines 1475-1479) and `whileStatementShareChoose` (lines 2038-2042) to upgrade `highestPC` to `top` (H) if branching on a high guard.

