# Clockwork

Clockwork is based on the dynamic monitor JSFlow (v1.1.0). Clockwork extends JSFlow's
context with two booleans (`theta` for tracking whether any time-reading clock invocations
have been made, and `lowOutputs` for tracking whether any low outputs have been produced)
and with a security label `highestPC` for tracking the highest program counter ever
pushed onto the stack. 
Although implemented on top of FlowIT (see below), Clockwork is not dependent on FlowIT.
Instead, it extends the security checks of FlowIT with new checks for tracking remote timing 
attacks.

For a detailed description of the extensions, refer to EXTENSION.md.


## Clockwork Contributors

* Iulia Bastys
* Musard Balliu
* Tamara Rezk
* Andrei Sabelfeld


# FlowIT

FlowIT is based on the dynamic monitor JSFlow (v1.1.0). FlowIT parameterizes JSFlow 
with a set of blacklisted domains `blackValues` and an action set `actionSet`, and 
extends the syntax with several constructs for sink declarations, action skipping, 
or URL upload and image creation. 

## Presence-sensitivity

- Presence-sensitive code is executed with flag `-sensitive`:
`./jsflow -sensitive presence_sensitive_code.js`

- No labels should be used in the code marked as presence-sensitive.

## FlowIT Contributors

* Iulia Bastys
* Musard Balliu
* Andrei Sabelfeld


# JSFlow 

[![Build Status](https://semaphoreci.com/api/v1/projects/ec57d3d7-dc77-4698-8159-7ad097cc01e2/700294/badge.svg)](https://semaphoreci.com/lbello/jsflow)
JSFlow is an information flow aware JavaScript interpreter written in JavaScript.

## Installation

Install the dependencies with `npm install`. 

## Execution

The monitor evaluates the code in `js_code.js` by executing the following command:
`./jsflow js_code.js`

## JSFlow contributors

* Daniel Hedin
* Alexander Sjösten
* Andrei Sabelfeld 

Former contributors:

* Arnar Birgisson
* Luciano Bello






